package com.CarWashWebApp.HomePage.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.CarWashWebApp.HomePage.model.HomePageModel;
import com.CarWashWebApp.HomePage.repository.HomePageRepo;

@RestController
public class HomePageController {
	
	@Autowired
	private HomePageRepo repository;
	
	@GetMapping("/")
	private String home() {
		return ("<h1>GREEN CAR WASH SERVICES</h1>"
				+ "<h3>LOGIN AS</h3>"
				+ "<h3><a href=\"http://localhost:8081/\">Admin</a><h3>"
				+ "<h3>Washer<h3>"
				+ "<h3><a href=\"http://localhost:8083/\">Customer</a></h3>"
				+ "<h3>--------------------</h3>"
				+ "<h4>New User? Register Here!<h4>");
	}
	
	@PostMapping("/components")
	public int saveBook(@RequestBody HomePageModel home) {
		repository.save(home);
		return home.getId();
	}
}
